package com.example.BHRC;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BhrcApplicationTests {

	@Test
	void contextLoads() {
	}

}
