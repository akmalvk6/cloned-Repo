package com.example.BHRC.repository;

import com.example.BHRC.model.TestServices;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TestServicesRepository extends JpaRepository<TestServices, Long> {
}
