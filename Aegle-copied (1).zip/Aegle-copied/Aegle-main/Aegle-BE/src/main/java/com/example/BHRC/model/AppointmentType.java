package com.example.BHRC.model;

public enum AppointmentType {
    INITIAL, FOLLOWUP
}
