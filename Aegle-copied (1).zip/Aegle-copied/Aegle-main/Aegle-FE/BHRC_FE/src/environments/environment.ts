export const environment = {
    production: false,
    apiBaseUrl: 'http://localhost:8080/v1/',
    featureFlag: {
      enableBetaFeatures: true
    }
  };
  