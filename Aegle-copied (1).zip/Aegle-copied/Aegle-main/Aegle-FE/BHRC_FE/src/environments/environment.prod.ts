export const environment = {
    production: true,
    apiUrl: 'https://api.myapp.com',
    featureFlag: {
      enableBetaFeatures: false
    }
  };
  